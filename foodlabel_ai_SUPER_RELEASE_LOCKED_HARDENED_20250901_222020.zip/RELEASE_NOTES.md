# FoodLabel AI v0.5.0 — Release Notes

- Mobile (Flutter): OCR, i18n, tests
- Backend (FastAPI): /v1/assess, Docker, tests
- Infra (Terraform): WIF + Stack
- CI/CD: infra, dev/prod/manual, Sentry, Flutter CI, Android build
- DX: Makefile, helpers, diagrams
