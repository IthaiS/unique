# REPO_STRUCTURE
- VERSION
- RELEASE_NOTES.md
- backend/**
- foodlabel-ai/mobile/**
- foodlabel-ai/infra/{wif,stack}/**
- .github/workflows/*.yml
- scripts/*.sh
- Makefile, commit_super_release.sh
- docs/ARCHITECTURE.md
