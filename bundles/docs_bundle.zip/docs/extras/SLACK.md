# Slack
Create an Incoming Webhook in Slack and store it in GCP Secret Manager (key `slack-webhook`).
Optionally extend backend to send alerts for 'avoid' verdicts.
