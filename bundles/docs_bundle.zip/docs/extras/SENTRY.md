# Sentry
Set `SENTRY_AUTH_TOKEN`, `SENTRY_ORG`, `SENTRY_PROJECT` in repository secrets.
The workflow `Sentry Release (versioned)` uses VERSION to tag releases.
