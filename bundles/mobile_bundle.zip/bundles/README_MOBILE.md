# Mobile Bundle
- Flutter app with OCR (ML Kit), i18n (en/nl-BE/fr-BE), tests, bootstrap.
