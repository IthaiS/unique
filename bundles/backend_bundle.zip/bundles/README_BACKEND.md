# Backend Bundle
- FastAPI service with `/v1/assess` endpoint.
- Dockerfile for Cloud Run, pytest suite, simple policy.
