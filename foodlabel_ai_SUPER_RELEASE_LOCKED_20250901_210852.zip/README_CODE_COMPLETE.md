# Code Complete
Includes mobile (Flutter) + backend (FastAPI) + workflows + infra.
See README_SUPER.md for end-to-end flow.
