# Mobile (Flutter)

Bootstrap platform folders and run:
```bash
./scripts/bootstrap_mobile.sh
flutter pub get
flutter run --dart-define=BACKEND_BASE_URL=https://<cloud-run-url>
```
