# WIF basic module
Apply:
```bash
cd foodlabel-ai/infra/wif
terraform init && terraform apply -auto-approve
```
