# Infra Stack (Extended)
Apply:
```bash
cd foodlabel-ai/infra/stack
cp terraform.tfvars.example terraform.tfvars && edit project_id, run_image as needed
terraform init && terraform apply -auto-approve
```
